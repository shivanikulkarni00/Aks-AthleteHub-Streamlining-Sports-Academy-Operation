package com.neww.service;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.neww.entity.User;
//import com.neww.repository.UserRepository;
//
//
//@Service
//public class UserService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//
//
//    
//    public List<User> getAllUsers() {
//        return userRepository.findAll();
//    }
//
//    public Optional<User> getUserByEmail(String email) {
//        return userRepository.findByEmail(email);
//    }
//
//    public User createUser(User user) {
//        return userRepository.save(user);
//    }
//
//    public User updateUser(Long id, User updatedUser) {
//        return userRepository.findById(id).map(user -> {
//            user.setEmail(updatedUser.getEmail());
//            user.setPassword(updatedUser.getPassword());
//            user.setRole(updatedUser.getRole());
//            return userRepository.save(user);
//        }).orElseThrow(() -> new RuntimeException("User not found"));
//    }
//
//    public void deleteUser(Long id) {
//        userRepository.deleteById(id);
//    }
//}
//package com.neww.service;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.neww.entity.User;
//import com.neww.repository.UserRepository;
//
//@Service
//public class UserService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//
//    // Get all users
//    public List<User> getAllUsers() {
//        return userRepository.findAll();
//    }
//
//    // Get user by email
//    public Optional<User> getUserByEmail(String email) {
//        return userRepository.findByEmail(email);
//    }
//
//    // Create a new user with encrypted password
//    public User createUser(User user) {
//        user.setPassword(passwordEncoder.encode(user.getPassword())); // Encrypt password
//        return userRepository.save(user);
//    }
//
//    // Update user and encrypt password if changed
//    public User updateUser(Long id, User updatedUser) {
//        return userRepository.findById(id).map(user -> {
//            user.setEmail(updatedUser.getEmail());
//            
//            // Encrypt password only if it is updated
//            if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty()) {
//                user.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
//            }
//            
//            user.setRole(updatedUser.getRole());
//            return userRepository.save(user);
//        }).orElseThrow(() -> new RuntimeException("User not found"));
//    }
//
//    // Delete user
//    public void deleteUser(Long id) {
//        userRepository.deleteById(id);
//    }
//}

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.neww.entity.User;
import com.neww.exception.UserAlredyExistException;
import com.neww.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepo;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public Collection<User> getAllUsers() {
        return userRepo.findAll();
    }

    public User RegisterUser(User user) throws UserAlredyExistException {
        if (userRepo.findByEmail(user.getEmail()).isPresent()) {
            throw new UserAlredyExistException("User already exists! with this Email");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepo.save(user);
    }

    public User getbyid(Long id) {
        return userRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("User not found"));
    }

    public User UpdateUser(Long id, User user) {
        User existingUser = userRepo.findById(id).orElse(null);
        if (existingUser != null) {
            existingUser.setEmail(user.getEmail());
            existingUser.setPassword(user.getPassword());
        }
        return userRepo.save(existingUser);
    }

//    public boolean authenticateUser(String email, String password) {
//        return userRepo.findByEmail(email)
//                .map(user -> passwordEncoder.matches(password, user.getPassword()))
//                .orElse(false);
//    }
    
    public Map<String, Object> authenticateUser(String email, String password) {
        return userRepo.findByEmail(email)
                .filter(user -> passwordEncoder.matches(password, user.getPassword()))
                .map(user -> {
                    Map<String, Object> response = new HashMap<>();
                    response.put("authenticated", true);
                    response.put("role", user.getRole()); // Assuming `getRole()` returns USER, TRAINER, or ADMIN
                    return response;
                })
                .orElseGet(() -> {
                    Map<String, Object> response = new HashMap<>();
                    response.put("authenticated", false);
                    return response;
                });
    }


    public Optional<User> FindByEmail(String email) {
        return userRepo.findByEmail(email);
    }
}
