package com.neww.controler;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.neww.entity.UserProfile;
import com.neww.service.UserProfileService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000") // Allow frontend to access this API
public class UserProfileController {
    
    @Autowired
    private UserProfileService userProfileService;

    @GetMapping
    public List<UserProfile> getAllUsers() {
        return userProfileService.getAllUsers();
    }

    @GetMapping("/{id}")
    public Optional<UserProfile> getUserById(@PathVariable Long id) {
        return userProfileService.getUserById(id);
    }

    @PostMapping
    public UserProfile createUser(@RequestBody UserProfile userProfile) {
        return userProfileService.saveUser(userProfile);
    }

    @PutMapping("/{id}")
    public UserProfile updateUser(@PathVariable Long id, @RequestBody UserProfile userProfile) {
        Optional<UserProfile> existingUser = userProfileService.getUserById(id);
        if (existingUser.isPresent()) {
            UserProfile updatedUser = existingUser.get();
            updatedUser.setName(userProfile.getName());
            updatedUser.setEmail(userProfile.getEmail());
            updatedUser.setPhone(userProfile.getPhone());
            updatedUser.setAge(userProfile.getAge());
            updatedUser.setAddress(userProfile.getAddress());
            return userProfileService.saveUser(updatedUser);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable Long id) {
        userProfileService.deleteUser(id);
        return "User deleted successfully!";
    }
}

