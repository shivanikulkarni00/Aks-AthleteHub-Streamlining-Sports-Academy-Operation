package com.neww.controler;

import com.neww.entity.TrainerProfile;
import com.neww.service.TrainerProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/trainer-profiles")
@CrossOrigin(origins = "*")  // Allows frontend access
public class TrainerProfileController {

    @Autowired
    private TrainerProfileService trainerProfileService;

    @PostMapping
    public ResponseEntity<TrainerProfile> createTrainerProfile(@RequestBody TrainerProfile trainerProfile) {
        TrainerProfile savedProfile = trainerProfileService.saveTrainerProfile(trainerProfile);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProfile);
    }

    @GetMapping
    public ResponseEntity<List<TrainerProfile>> getAllProfiles() {
        return ResponseEntity.ok(trainerProfileService.getAllTrainerProfiles());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TrainerProfile> getProfileById(@PathVariable Long id) {
        Optional<TrainerProfile> profile = trainerProfileService.getTrainerProfileById(id);
        return profile.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<TrainerProfile> updateProfile(@PathVariable Long id, @RequestBody TrainerProfile updatedProfile) {
        try {
            TrainerProfile profile = trainerProfileService.updateTrainerProfile(id, updatedProfile);
            return ResponseEntity.ok(profile);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProfile(@PathVariable Long id) {
        trainerProfileService.deleteTrainerProfile(id);
        return ResponseEntity.noContent().build();
    }
}
