package com.neww.service;




import org.springframework.stereotype.Service;

import com.neww.entity.Contact;
import com.neww.repository.ContactRepository;

import java.util.List;

@Service
public class ContactService {
    
    private final ContactRepository contactRepository;

    public ContactService(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    // Save contact details
    public Contact saveContact(Contact contact) {
        return contactRepository.save(contact);
    }

    // Retrieve all contact messages
    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }
}

