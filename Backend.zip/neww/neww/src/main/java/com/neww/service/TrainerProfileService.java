package com.neww.service;

import com.neww.entity.TrainerProfile;
import com.neww.repository.TrainerProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrainerProfileService {

    @Autowired
    private TrainerProfileRepository trainerProfileRepository;

    public TrainerProfile saveTrainerProfile(TrainerProfile trainerProfile) {
        return trainerProfileRepository.save(trainerProfile);
    }

    public List<TrainerProfile> getAllTrainerProfiles() {
        return trainerProfileRepository.findAll();
    }

    public Optional<TrainerProfile> getTrainerProfileById(Long id) {
        return trainerProfileRepository.findById(id);
    }

    public TrainerProfile updateTrainerProfile(Long id, TrainerProfile updatedProfile) {
        return trainerProfileRepository.findById(id).map(profile -> {
            profile.setName(updatedProfile.getName());
            profile.setEmail(updatedProfile.getEmail());
            profile.setExpertise(updatedProfile.getExpertise());
            profile.setExperience(updatedProfile.getExperience());
            return trainerProfileRepository.save(profile);
        }).orElseThrow(() -> new RuntimeException("Trainer Profile not found"));
    }

    public void deleteTrainerProfile(Long id) {
        trainerProfileRepository.deleteById(id);
    }
}
