package com.neww.controler;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.neww.entity.User;
//import com.neww.service.UserService;
//
//
//
//@RestController
//@RequestMapping("/api/users")
//@CrossOrigin("*") 
//public class UserController {
//	 @Autowired
//	    private UserService userService;
//
//	    // ✅ Get all users
//	    @GetMapping
//	    public List<User> getAllUsers() {
//	        return userService.getAllUsers();
//	    }
//
//	    // ✅ Get user by email
//	    @GetMapping("/{email}")
//	    public Optional<User> getUserByEmail(@PathVariable String email) {
//	        return userService.getUserByEmail(email);
//	    }
//
//	    // ✅ Create a new user
//	    @PostMapping
//	    public User createUser(@RequestBody User user) {
//	        return userService.createUser(user);
//	    }
//
//	    // ✅ Update user
//	    @PutMapping("/{id}")
//	    public User updateUser(@PathVariable Long id, @RequestBody User user) {
//	        return userService.updateUser(id, user);
//	    }
//
//	    // ✅ Delete user
//	    @DeleteMapping("/{id}")
//	    public void deleteUser(@PathVariable Long id) {
//	        userService.deleteUser(id);
//	    }
//}

//
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.neww.entity.User;
//import com.neww.service.UserService;
//
//@RestController
//@RequestMapping("/api/users")
//@CrossOrigin("*")
//public class UserController {
//
//    @Autowired
//    private UserService userService;
//
//    // ✅ Get all users
//    @GetMapping
//    public ResponseEntity<List<User>> getAllUsers() {
//        return ResponseEntity.ok(userService.getAllUsers());
//    }
//
//    // ✅ Get user by email
//    @GetMapping("/{email}")
//    public ResponseEntity<Optional<User>> getUserByEmail(@PathVariable String email) {
//        Optional<User> user = userService.getUserByEmail(email);
//        return user.isPresent() ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
//    }
//
//    // ✅ Create a new user with encrypted password
//    @PostMapping
//    public ResponseEntity<User> createUser(@RequestBody User user) {
//        User createdUser = userService.createUser(user);
//        return ResponseEntity.ok(createdUser);
//    }
//
//    // ✅ Update user (encrypts new password if provided)
//    @PutMapping("/{id}")
//    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
//        try {
//            User updatedUser = userService.updateUser(id, user);
//            return ResponseEntity.ok(updatedUser);
//        } catch (RuntimeException e) {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    // ✅ Delete user
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
//        userService.deleteUser(id);
//        return ResponseEntity.noContent().build();
//    }
//}


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.neww.entity.User;
import com.neww.exception.UserAlredyExistException;
import com.neww.service.UserService;

import jakarta.persistence.EntityNotFoundException;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<Collection<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {
            return ResponseEntity.ok(userService.RegisterUser(user));
        } catch (UserAlredyExistException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(userService.getbyid(id));
        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id, @RequestBody User user) {
        User updatedUser = userService.UpdateUser(id, user);
        if (updatedUser != null) {
            return ResponseEntity.ok(updatedUser);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

//    @PostMapping("/authenticate")
//    public ResponseEntity<?> authenticateUser(@RequestParam String email, @RequestParam String password) {
//        boolean isAuthenticated = userService.authenticateUser(email, password);
//        if (isAuthenticated) {
//            return ResponseEntity.ok("User authenticated successfully");
//        } else {
//            return ResponseEntity.status(401).body("Invalid credentials");
//        }
//    }
    
    @PostMapping("/authenticate")
    public ResponseEntity<?> authenticateUser(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String password = request.get("password");

        if (email == null || password == null) {
            return ResponseEntity.badRequest().body("Email and password are required");
        }

        Map<String, Object> authResult = userService.authenticateUser(email, password);

        if ((boolean) authResult.get("authenticated")) {
            return ResponseEntity.ok(authResult); // Returns { authenticated: true, role: "USER/ADMIN/TRAINER" }
        } else {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }



    @GetMapping("/find")
    public ResponseEntity<?> findByEmail(@RequestParam String email) {
        Optional<User> user = userService.FindByEmail(email);
        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}